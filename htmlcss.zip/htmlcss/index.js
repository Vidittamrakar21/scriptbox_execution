const  express =  require('express');
const cors =  require('cors');
const morgan =  require('morgan');
const path = require('path');




    const app = express();

    app.use(express.json());
    app.use(cors());
    app.use(morgan('tiny'));
    app.use(express.static(path.join(__dirname, 'public')));

//entry point

app.get('/', (req,res)=>{
    try {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));

    } catch (error) {
        res.json(error)
    }
})




const server = app.listen(3000, ()=>{

    //app will start running on port 8080, you can change the port according to your need .

    console.log("server started")
})


module.exports = server;