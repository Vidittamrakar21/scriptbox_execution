const btn = document.getElementById('btnn');

btn.addEventListener('click', ()=>{
    alert("button clicked")
})