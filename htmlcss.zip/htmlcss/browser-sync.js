const browserSync = require('browser-sync');
const browserSyncConfig = {
  files: ['public/**/*.*'],
  proxy: 'http://localhost:3000',
  port: 3000,
  open: false,
  notify: false
};

browserSync.init(browserSyncConfig);
